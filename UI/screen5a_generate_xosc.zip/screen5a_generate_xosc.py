# screen5a_generate_xosc.py
import streamlit as st
from ui_utils import navigate_to, show_progress, get_rag_functions

def show():
    show_progress()

    provider = "claude"  # DEMO default

    current_scenario = st.session_state.get("current_scenario_for_generation")
    scenario_name = st.session_state.get("current_scenario_name", "scenario")

    filename = f"{scenario_name}.xosc"

    st.markdown(f"<h1>Generating: {filename}</h1>", unsafe_allow_html=True)
    st.markdown("<br>", unsafe_allow_html=True)

    generate_python, generate_xosc = get_rag_functions()
    if not generate_xosc:
        st.error("❌ XOSC generation function not available!")
        return

    # Auto-generate once when arriving
    if st.session_state.get("auto_generate") == "xosc" and scenario_name not in st.session_state.xosc_code:
        with st.spinner(f"Generating XOSC"):
            try:
                xosc_code = generate_xosc(current_scenario, provider=provider)
                st.session_state.xosc_code[scenario_name] = xosc_code
                st.success("✅ XOSC generated!")
            except Exception as e:
                st.error(f"❌ Generation failed: {e}")
        st.session_state.auto_generate = None

    # Show code + download
    if scenario_name in st.session_state.xosc_code:
        st.code(st.session_state.xosc_code[scenario_name], language="xml", line_numbers=True)
        st.download_button(
            "📥 DOWNLOAD XOSC",
            st.session_state.xosc_code[scenario_name],
            file_name=filename,
            mime="application/xml",
            use_container_width=True
        )
    else:
        if st.button("Generate XOSC", use_container_width=True):
            st.session_state.auto_generate = "xosc"
            st.rerun()

    st.markdown("<br>", unsafe_allow_html=True)

    c1, c2 = st.columns([1, 1])
    with c1:
        if st.button("← Back to Code Generation", use_container_width=True):
            navigate_to("generate")
    with c2:
        if st.button("Generate Python Instead →", use_container_width=True):
            st.session_state.auto_generate = "python"
            navigate_to("generate_python")

# mainUIlauncher.py - Main entry point for ADASynAI
"""
ADASynAI - ADAS Scenario Generator
Main launcher that coordinates all screens

Run with: streamlit run mainUIlauncher.py
"""

import streamlit as st

# Import utilities
from ui_utils import init_session_state, apply_custom_css, get_current_page

# Import all screens
import screen1_standards
import screen2_upload
import screen3_info
import screen4_features
import screen5_generate

# NEW: generation sub-screens (add these two files in your repo)
import screen5a_generate_xosc
import screen5b_generate_python

# -------------------------
# Page Configuration
# -------------------------
st.set_page_config(
    page_title="ADASynAI - Scenario Generator",
    page_icon="🚗",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# -------------------------
# Initialize
# -------------------------
apply_custom_css()
init_session_state()

# -------------------------
# Main Router
# -------------------------
def main():
    """
    Main application router
    Routes to appropriate screen based on session state
    """

    page = get_current_page()

    if page == 'standards':
        screen1_standards.show()

    elif page == 'upload':
        screen2_upload.show()

    elif page == 'info':
        screen3_info.show()

    elif page == 'features':
        screen4_features.show()

    elif page == 'generate':
        screen5_generate.show()

    # NEW: separate generation pages
    elif page == 'generate_xosc':
        screen5a_generate_xosc.show()

    elif page == 'generate_python':
        screen5b_generate_python.show()

    else:
        st.error(f"❌ Unknown page: {page}")
        st.info("Redirecting to standards selection...")
        st.session_state.page = 'standards'
        st.rerun()

# -------------------------
# Entry Point
# -------------------------
if __name__ == "__main__":
    main()

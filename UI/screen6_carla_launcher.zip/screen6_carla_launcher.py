"""
carla_launcher.py

Streamlit page for launching CARLA and ScenarioRunner automatically.
Place this file in your UI folder and add it to your Streamlit navigation.

Usage (add to your main app or as a separate page):
    streamlit run carla_launcher.py
"""

import subprocess
import threading
import time
import os
import signal
import streamlit as st


def show():

    # ─────────────────────────────────────────────
    # CONFIG — update these paths to match your machine
    # ─────────────────────────────────────────────
    CARLA_ROOT = os.path.expanduser("~/CARLA_0.9.15")
    SCENARIO_RUNNER_ROOT = os.path.expanduser("~/scenario_runner")
    CARLA_PYTHON_API = os.path.join(CARLA_ROOT, "PythonAPI")
    CARLA_EGG = None  # auto-detected below

    # Auto-detect .egg file
    import glob
    eggs = glob.glob(os.path.join(CARLA_ROOT, "PythonAPI/carla/dist/*py3*.egg"))
    if eggs:
        CARLA_EGG = eggs[0]

    PYTHONPATH_EXTRA = ":".join(filter(None, [
        CARLA_EGG,
        os.path.join(CARLA_ROOT, "PythonAPI/carla"),
        os.path.join(CARLA_ROOT, "PythonAPI"),
    ]))

    CARLA_CMD = [
        os.path.join(CARLA_ROOT, "CarlaUE4.sh"),
        "-RenderOffScreen",
        "-quality-level=Low"
    ]

    # ─────────────────────────────────────────────
    # SESSION STATE INIT
    # ─────────────────────────────────────────────
    def init_state():
        defaults = {
            "carla_process": None,
            "scenario_process": None,
            "carla_logs": [],
            "scenario_logs": [],
            "carla_status": "stopped",   # stopped | starting | running | crashed
            "scenario_status": "stopped", # stopped | starting | running | finished | error
            "launch_started": False,
        }
        for k, v in defaults.items():
            if k not in st.session_state:
                st.session_state[k] = v

    init_state()

    # ─────────────────────────────────────────────
    # BACKGROUND LOG READER
    # ─────────────────────────────────────────────
    def stream_logs(process, log_key, status_key, ready_marker=None):
        """Read process stdout in background thread and append to session state list."""
        for line in iter(process.stdout.readline, b""):
            decoded = line.decode("utf-8", errors="replace").rstrip()
            st.session_state[log_key].append(decoded)
            # Detect if CARLA is ready
            if ready_marker and ready_marker in decoded:
                st.session_state[status_key] = "running"
        # Process ended
        rc = process.wait()
        if st.session_state[status_key] not in ("stopped",):
            st.session_state[status_key] = "finished" if rc == 0 else "crashed"


    # ─────────────────────────────────────────────
    # LAUNCH FUNCTIONS
    # ─────────────────────────────────────────────
    def launch_carla():
        st.session_state["carla_status"] = "starting"
        st.session_state["carla_logs"] = []
        env = os.environ.copy()
        proc = subprocess.Popen(
            CARLA_CMD,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            env=env,
            preexec_fn=os.setsid
        )
        st.session_state["carla_process"] = proc
        t = threading.Thread(
            target=stream_logs,
            args=(proc, "carla_logs", "carla_status", "Server listening"),
            daemon=True
        )
        t.start()


    def launch_scenario(xosc_path):
        st.session_state["scenario_status"] = "starting"
        st.session_state["scenario_logs"] = []
        env = os.environ.copy()
        existing_pp = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = PYTHONPATH_EXTRA + (":" + existing_pp if existing_pp else "")

        cmd = [
            "python", "scenario_runner.py",
            "--openscenario", xosc_path,
            "--reloadWorld"
        ]
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            env=env,
            cwd=SCENARIO_RUNNER_ROOT,
            preexec_fn=os.setsid
        )
        st.session_state["scenario_process"] = proc
        t = threading.Thread(
            target=stream_logs,
            args=(proc, "scenario_logs", "scenario_status"),
            daemon=True
        )
        t.start()


    def stop_all():
        for key in ["carla_process", "scenario_process"]:
            proc = st.session_state.get(key)
            if proc and proc.poll() is None:
                try:
                    os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                except Exception:
                    proc.terminate()
        st.session_state["carla_status"] = "stopped"
        st.session_state["scenario_status"] = "stopped"
        st.session_state["carla_process"] = None
        st.session_state["scenario_process"] = None
        st.session_state["launch_started"] = False


    # ─────────────────────────────────────────────
    # STATUS BADGE HELPER
    # ─────────────────────────────────────────────
    STATUS_COLORS = {
        "stopped":  ("⚪", "gray"),
        "starting": ("🟡", "orange"),
        "running":  ("🟢", "green"),
        "finished": ("✅", "green"),
        "crashed":  ("🔴", "red"),
        "error":    ("🔴", "red"),
    }

    def status_badge(label, status):
        icon, _ = STATUS_COLORS.get(status, ("⚪", "gray"))
        st.markdown(f"**{label}:** {icon} `{status.upper()}`")


    # ─────────────────────────────────────────────
    # UI
    # ─────────────────────────────────────────────
    st.title("🚗 Launch in CARLA")
    st.markdown("Automates launching CARLA and running the generated scenario in ScenarioRunner.")

    st.divider()

    # ── XOSC path input ──────────────────────────
    st.subheader("📁 Scenario File")
    xosc_path = st.text_input(
        "Path to generated .xosc file",
        value=os.path.join(SCENARIO_RUNNER_ROOT, "srunner/examples/Car-to-Car Rear Stationary.xosc"),
        help="Full path to the OpenSCENARIO file generated by your RAG system"
    )

    st.divider()

    # ── STATUS ───────────────────────────────────
    st.subheader("📊 Status")
    col1, col2 = st.columns(2)
    with col1:
        status_badge("CARLA Simulator", st.session_state["carla_status"])
    with col2:
        status_badge("Scenario Runner", st.session_state["scenario_status"])

    st.divider()

    # ── LAUNCH CONTROLS ──────────────────────────
    st.subheader("🎮 Controls")
    col1, col2, col3 = st.columns(3)

    with col1:
        if st.button("🚀 Launch CARLA + Scenario", type="primary", use_container_width=True,
                     disabled=st.session_state["launch_started"]):
            if not os.path.exists(xosc_path):
                st.error(f"❌ XOSC file not found: {xosc_path}")
            else:
                st.session_state["launch_started"] = True
                launch_carla()
                # Wait for CARLA to start before launching scenario runner
                with st.spinner("⏳ Waiting for CARLA to start (30s)..."):
                    time.sleep(30)
                launch_scenario(xosc_path)
                st.rerun()

    with col2:
        if st.button("🔄 Refresh Status", use_container_width=True):
            st.rerun()

    with col3:
        if st.button("🛑 Stop All", type="secondary", use_container_width=True,
                     disabled=not st.session_state["launch_started"]):
            stop_all()
            st.success("All processes stopped.")
            st.rerun()

    st.divider()

    # ── LOGS ─────────────────────────────────────
    st.subheader("📋 Live Logs")
    log_col1, log_col2 = st.columns(2)

    with log_col1:
        st.markdown("**🖥️ CARLA Simulator Logs**")
        carla_logs = st.session_state["carla_logs"]
        if carla_logs:
            st.code("\n".join(carla_logs[-50:]), language="bash")  # show last 50 lines
        else:
            st.info("No logs yet. Launch CARLA to see output.")

    with log_col2:
        st.markdown("**🏁 Scenario Runner Logs**")
        scenario_logs = st.session_state["scenario_logs"]
        if scenario_logs:
            st.code("\n".join(scenario_logs[-50:]), language="bash")
        else:
            st.info("No logs yet. Scenario will start after CARLA is ready.")

    # Auto-refresh every 2 seconds while running
    if st.session_state["launch_started"]:
        time.sleep(2)
        st.rerun()
